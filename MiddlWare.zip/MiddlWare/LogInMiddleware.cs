using System.Diagnostics;
using Microsoft.AspNetCore.Http;

public class LogInMiddleware
{
    private readonly RequestDelegate _next;
    public LogInMiddleware(RequestDelegate next)
    {
        _next = next;
    }
    public async Task InvokeAsync(HttpContext context)
    {
        HttpRequest request = context.Request;
        HttpResponse response = context.Response;



        string log = "Schema: " + request.Scheme
  + "Hot: " + request.Host
  + "Path: " + request.Path
  + "Query string: " + request.QueryString
  + "Request body: " + request.Body;
        using (var buffer = new MemoryStream())
        {
            await _next(context);
            Debug.Write(log);
            //buffer.Position = 0;
            // await buffer.CopyToAsync(stream);
            using (FileStream file = new FileStream("file.txt", FileMode.Create, System.IO.FileAccess.Write))
                await buffer.CopyToAsync(file);
        }

    }
}
