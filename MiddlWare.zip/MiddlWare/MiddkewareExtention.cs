using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;


namespace MiddlWare
{
    public static class MiddkewareExtention
    {
        public static IApplicationBuilder UseLogInMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<LogInMiddleware>();
        }
    }
}